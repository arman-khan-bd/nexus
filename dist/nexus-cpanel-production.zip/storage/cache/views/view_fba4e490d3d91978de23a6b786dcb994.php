<?php

declare(strict_types=1);

/**
 * Sub-Layout: /demo/test-page
 */
?>
<div class="nested-sublayout border-l-2 border-blue-500/30 pl-4 my-2">
    <?= $children ?>
</div>