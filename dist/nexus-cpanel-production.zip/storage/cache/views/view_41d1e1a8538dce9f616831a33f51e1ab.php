<?php

declare(strict_types=1);

/**
 * Page: /demo/test-page
 */

// Route parameters passed by Nexus AppRouter

$pageTitle = "Demo Test Page | Nexus";
?>
<div class="space-y-6">
    <div class="flex items-center justify-between border-b border-slate-800 pb-5">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-white">Demo Test Page</h1>
            <p class="text-sm text-slate-400 mt-1">Managed via NextPHP App Router file-system convention.</p>
        </div>
        <?= \Core\UI\ComponentRegistry::render('Link', ['href' => '/', 'icon' => 'arrow-left', 'class' => 'text-sm text-slate-400 hover:text-white'], function() use (&$__context) { extract($__context, EXTR_SKIP); ?>Back to Home<?php }) ?>
    </div>

    <?= \Core\UI\ComponentRegistry::render('Card', ['title' => 'Route Details', 'description' => 'Parameters and active state', 'class' => 'bg-slate-900 border-slate-800'], function() use (&$__context) { extract($__context, EXTR_SKIP); ?>
        <div class="space-y-4">
            <div class="flex items-center gap-2">
                <?= \Core\UI\ComponentRegistry::render('Badge', ['variant' => 'outline'], function() use (&$__context) { extract($__context, EXTR_SKIP); ?>Route: /demo/test-page<?php }) ?>
                <?= \Core\UI\ComponentRegistry::render('Badge', ['variant' => 'success'], function() use (&$__context) { extract($__context, EXTR_SKIP); ?>Active<?php }) ?>
            </div>
            <p class="text-sm text-slate-300">
                This page is compiled on-demand into cached native PHP via <code>JsxCompiler</code>.
            </p>
        </div>
    <?php }) ?>

    <?= \Core\UI\ComponentRegistry::render('Card', ['title' => 'Server Action Test', 'description' => 'Direct zero-AJAX action execution', 'class' => 'bg-slate-900 border-slate-800'], function() use (&$__context) { extract($__context, EXTR_SKIP); ?>
        <?= \Core\UI\ComponentRegistry::render('Form', ['nexusAction' => 'saveSample', 'class' => 'space-y-4'], function() use (&$__context) { extract($__context, EXTR_SKIP); ?>
            <?= \Core\UI\ComponentRegistry::render('Input', ['name' => 'title', 'label' => 'Item Title', 'placeholder' => 'Enter title...', 'required' => true]) ?>
            <?= \Core\UI\ComponentRegistry::render('Button', ['type' => 'submit', 'variant' => 'default', 'icon' => 'shield-check'], function() use (&$__context) { extract($__context, EXTR_SKIP); ?>Execute Action<?php }) ?>
        <?php }) ?>
    <?php }) ?>
</div>